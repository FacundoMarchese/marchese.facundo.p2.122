package resources;

import model.CSVSerializable;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class ColeccionPersonajes<T extends CSVSerializable & Serializable> implements Serializable {

    private static final long serialVersionUID = 1L;

    private final List<T> elementos = new ArrayList<>();

    public void agregar(T item) {
        if (item == null) throw new NullPointerException("No se permite null");
        elementos.add(item);
    }

    public T obtener(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango: " + indice);
        }
        return elementos.get(indice);
    }

    public T eliminar(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango: " + indice);
        }
        return elementos.remove(indice);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> res = new ArrayList<>();
        for (T e : elementos) {
            if (criterio.test(e)) res.add(e);
        }
        return res;
    }

    public void ordenar(Comparator<? super T> comp) {
        if (comp == null) {
            // try natural ordering
            if (!elementos.isEmpty() && elementos.get(0) instanceof Comparable) {
                @SuppressWarnings("unchecked")
                List<Comparable> tmp = (List<Comparable>)(List<?>) elementos;
                Collections.sort(tmp);
            } else {
                // nothing to do
            }
        } else {
            elementos.sort(comp);
        }
    }

    public void ordenarNatural() {
        ordenar(null);
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T e : new ArrayList<>(elementos)) {
            accion.accept(e);
        }
    }

    public int tamanio() { return elementos.size(); }

    public List<T> obtenerTodos() {
        return new ArrayList<>(elementos);
    }

    // Serialization to binary file
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }
    }

    @SuppressWarnings("unchecked")
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            Object obj = ois.readObject();
            if (!(obj instanceof List)) {
                throw new IOException("Contenido de archivo inválido");
            }
            elementos.clear();
            elementos.addAll((Collection<? extends T>) obj);
        }
    }

    // CSV persistence
    public void guardarEnCSV(String ruta) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (T e : elementos) {
                bw.write(e.toCSV());
                bw.newLine();
            }
        }
    }

    // parser: Function<String,T> that converts a CSV line to T
    public void cargarDesdeCSV(String ruta, Function<String, ? extends T> parser) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            elementos.clear();
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                T obj = parser.apply(linea);
                if (obj != null) elementos.add(obj);
            }
        }
    }
}
