package persistence;

import java.io.File;

public final class IOUtils {
    private IOUtils() {}

    public static void ensureParentDirectoryExists(String path) {
        File f = new File(path);
        File parent = f.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
    }
}
