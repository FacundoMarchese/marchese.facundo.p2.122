package model;

import java.io.Serializable;
import java.util.Objects;

public class Personaje implements Comparable<Personaje>, Serializable, CSVSerializable {

    private static final long serialVersionUID = 1L;

    private final int id;
    private final String nombre;
    private final String creador;
    private final RolPersonaje rol;

    public Personaje(int id, String nombre, String creador, RolPersonaje rol) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.rol = rol;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCreador() { return creador; }
    public RolPersonaje getRol() { return rol; }

    @Override
    public int compareTo(Personaje otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Personaje)) return false;
        Personaje that = (Personaje) o;
        return id == that.id &&
                Objects.equals(nombre, that.nombre) &&
                Objects.equals(creador, that.creador) &&
                rol == that.rol;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre, creador, rol);
    }

    @Override
    public String toString() {
        return "Personaje{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", creador='" + creador + '\'' +
                ", rol=" + rol +
                '}';
    }

    @Override
    public String toCSV() {
        // CSV: id,nombre,creador,ROL
        return String.format("%d,%s,%s,%s", id, nombre, creador, rol);
    }

    public static Personaje fromCSV(String linea) {
        if (linea == null || linea.trim().isEmpty()) {
            throw new IllegalArgumentException("Línea CSV vacía");
        }
        String[] parts = linea.split(",", -1);
        if (parts.length != 4) {
            throw new IllegalArgumentException("Formato CSV inválido: " + linea);
        }
        int id = Integer.parseInt(parts[0].trim());
        String nombre = parts[1].trim();
        String creador = parts[2].trim();
        RolPersonaje rol = RolPersonaje.valueOf(parts[3].trim());
        return new Personaje(id, nombre, creador, rol);
    }
}
